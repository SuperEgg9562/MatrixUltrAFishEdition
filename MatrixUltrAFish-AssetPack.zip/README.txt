# Matrix UltrAFish Asset Pack

## Included Files
- Build.png
- Run.png
- Debug.png
- SolutionExplorer.png
- TitleBarBackground.png

## Recommended Font
- Cascadia Code
- Consolas
- JetBrains Mono

## Recommended Visual Studio Settings
- Environment Font: Cascadia Code
- Editor Font: Cascadia Code, 12 pt
- Theme: MatrixUltrAFish-PixelPerfect.vstheme

## Optional Nerd Fonts
For additional glyphs and symbols:
- Cascadia Code NF
- JetBrainsMono Nerd Font
